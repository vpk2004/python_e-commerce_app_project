import random

characters = "qwertyuioplkjhgfdsazxcvbnm0987654321QWERTYUIOPLKJHGFDSAZXCVBNM!@#$%^&*"
length = int(input("Enter the Length:"))
password=""
for a in range(length):
    password+=random.choice(characters)

print(password)